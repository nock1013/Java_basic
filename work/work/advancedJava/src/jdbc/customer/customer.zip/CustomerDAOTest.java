package jdbc.customer;

import java.util.Scanner;

import jdbc.basic.PreparedDeleteTest;
import jdbc.basic.PreparedInsertTest;
import jdbc.basic.PreparedUpdateTest;

public class CustomerDAOTest {
	
	public static void main(String[] args) {
		Scanner key = new Scanner(System.in);
		CustomerDAO dao = new CustomerDAO();
		System.out.println("********����*************");
		System.out.print("���̵� :");
		String id = key.next();
		System.out.print("��ȣ :");
		String password = key.next();
		System.out.print("���̵� :");
		String name = key.next();
		System.out.print("��ȣ :");
		String addr = key.next();
		System.out.println();
		CustomerDTO dto = new CustomerDTO(id, password, name, addr);
		dao.insert(customer);
	}
	
	
	/*public static void main(String[] args) {	
		Scanner key = new Scanner(System.in);
		BoardDAO dao = new BoardDAO();
		System.out.println("********����*************");
		System.out.print("��ȣ :");
		int boardnum = key.nextInt();
		System.out.println();
		dao.delete(boardnum);
	}*/
	

/*	public static void main(String[] args) {
	    Scanner key = new Scanner(System.in);
		BoardDAO dao = new BoardDAO();
		System.out.println("********�Խñ� ���*************");
		System.out.print("���̵� :");
		String id = key.next();
		System.out.print("���� :");
		String title = key.next();
		System.out.print("���� :");
		String content = key.next();
		System.out.println();
		dao.insert(id, title, content);
	}*/

}
